<?php

namespace App\Controllers;

class SecurityController extends BaseController
{
    public function index()
    {
        return view('security/scan_v');
    }
    public function dashboard()
    {
         return view('security/dashboard_v');
    }
    public function import()
    {
         return view('import_page_v');
    }
    public function detail_scrap_info()
    {
        return view('security/form_detail_scrap_info_v');
    }
    public function detail_scrap_verified()
    {
        return view('security/form_detail_scrap_verified_v');
    }
    public function detail_chemical_info()
    {
        return view('security/form_detail_chemical_info_v');
    }
    public function detail_chemical_verified()
    {
        return view('security/form_detail_chemical_verified_v');
    }

}