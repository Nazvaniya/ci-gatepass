<?php

namespace App\Controllers;

use App\Libraries\MY_TCPDF AS TCPDF;

class PdfController extends BaseController
{

    public function cetak()
    {

        // create new PDF document
        $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
        
        // set document information
        $pdf->SetCreator(PDF_CREATOR);
        $pdf->SetAuthor('');
        $pdf->SetTitle('');
        $pdf->SetSubject('');
        $pdf->SetKeywords('TCPDF, PDF, example, ');

        // set default header data
        $pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 001', PDF_HEADER_STRING, array(0,64,255), array(0,64,128));
        $pdf->setFooterData(array(0,64,0), array(0,64,128));

        // set header and footer fonts
        $pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
        $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

        // set default monospaced font
        $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

        // set margins
        $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
        $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
        $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

        // set auto page breaks
        $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

        // set image scale factor
        $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

        // set default font subsetting mode
        $pdf->setFontSubsetting(true);

        // Set font
        // dejavusans is a UTF-8 Unicode font, if you only need to
        // print standard ASCII chars, you can use core fonts like
        // helvetica or times to reduce file size.
        $pdf->SetFont('dejavusans', '', 14, '', true);

        // Add a page
        // This method has several options, check the source code documentation for more information.
        $pdf->AddPage();
        
        $pdf->SetFont('times','B', 12);
        $pdf->Cell(60, 10, 'PIDSG - BT',1,0,'C');
        $pdf->Cell(60, 10, 'GATE PASS',1,0,'C');
        $pdf->Cell(60, 10, 'HUMAN RESOURCE',1,1,'C');
        $pdf->Ln(5);
        $pdf->Cell(50, 5, 'From :',0,0);
        $pdf->Cell(70, 5, '(                        Section)',0,0);
        $pdf->Cell(60, 5, 'No.  :',0,1);
        $pdf->SetX(135);
        $pdf->Cell(189, 5, 'Date:',0,1);
        $pdf->Cell(189, 5, 'To: Security Guard',0,1);
        $pdf->Ln(5);
        $pdf->SetX(23);
        $pdf->Cell(90, 5, 'Bearer (Name):',0,0);
        $pdf->Cell(90, 5, 'NIRC No  :',0,1);
        $pdf->Ln(5);
        $pdf->SetX(113);
        $pdf->Cell(90, 5, 'Vehicle No:',0,1);
        $pdf->Ln(5);
        $pdf->SetFillColor(224,235,255);
        $pdf->Cell(20, 5, 'S/No', 1, 0, 'C',1);
        $pdf->Cell(80, 5, 'PARTICULARS', 1, 0, 'C',1);
        $pdf->Cell(40, 5, 'Quantity', 1, 0, 'C',1);
        $pdf->Cell(40, 5, 'Remarks', 1, 0, 'C',1);  
        $pdf->Ln(110);
        $pdf->Cell(80, 5, 'Issued By        :',0,0);
        $pdf->Cell(60, 5, 'Section:',0,0);
        $pdf->Cell(60, 5, 'Signature:',0,1);
        $pdf->Ln(15);
        $pdf->Cell(80, 5, 'Authorized By:',0,0);
        $pdf->Cell(60, 5, 'Section:',0,0);
        $pdf->Cell(60, 5, 'Signature:',0,1);
        $pdf->Ln(15);
        $pdf->Cell(90, 5, 'Return Type                    :',0,0);
        $pdf->Cell(90, 5, 'Remark                        :',0,1);
        $pdf->Cell(90, 5, 'Expected Date of Return:',0,0);
        $pdf->Cell(90, 5, 'Actual Date of Return:',0,1);
        $pdf->Ln(5);
        $pdf->Cell(189, 5, 'use at Security Gate',0,1);
        $pdf->Ln(5);
        $pdf->Cell(90, 5, 'Checked & Verified By:  ',0,0);
        $pdf->Cell(90, 5, 'Signature:',0,1);
        $pdf->SetX(34);
        $pdf->Cell(189, 5, 'Date & Time:',0,1);
        // $pdf->Cell(130, 5, 'Return Type:',0,0);
        // $pdf->Cell(59, 5, 'No.:',0,1);
        // $pdf->Cell(189, 5, 'LETTER OF AUTHORIZATION FOR OUTGOING GOODS VEHICLES',0,1);
        // $pdf->Ln(2);
        // $pdf->Cell(189, 5, '(A)  PARTICULAR',0,1);
        // $pdf->SetX(23);
        // $pdf->Cell(123, 5, 'Name of Company:',0,0);
        // $pdf->Cell(59, 5, 'Date:',0,1);
        // $pdf->Ln(2);
        // $pdf->SetX(23);
        // $pdf->Cell(189, 5, 'Name of Driver     :',0,1);
        // $pdf->Ln(2);
        // $pdf->SetX(23);
        // $pdf->Cell(189, 5, 'Vehicle Regn No.  :',0,1);
        // $pdf->Ln(2);
        // $pdf->Cell(63, 5, 'Type of Goods', 0, 0, 'R');
        // $pdf->Cell(63, 5, 'Quantity', 0, 1, 'R');
        // $pdf->Ln(100);
        // $pdf->SetX(23);
        // $pdf->Cell(189, 5, "Name of Authorizing Officer:", 0, 1);
        // $pdf->Ln(2);
        // $pdf->SetX(23);
        // $pdf->Cell(109, 5, "Designation                             :", 0, 0);
        // $pdf->Cell(80, 5, "Contact No                  :", 0, 1);
        // $pdf->Ln(2);
        // $pdf->SetX(23);
        // $pdf->Cell(109, 5, "Name of Issued                       :", 0, 0);
        // $pdf->Cell(80, 5, "Remark                        :", 0, 1);
        // $pdf->Ln(2);
        // $pdf->SetX(23);
        // $pdf->Cell(109, 5, "Expected Date of Return       :", 0, 0);
        // $pdf->Cell(80, 5, "Actual Date of Return:", 0, 0);
        // $pdf->Ln(10);
        // $pdf->SetX(23);
        // $pdf->Cell(109, 5, "Signature Authorizing           :", 0,0);
        // $pdf->Cell(80, 5, "Signature Issued          :", 0,0);
        // $pdf->Ln(20);
        // $pdf->Cell(189, 5, "(B)  SECURITY CHECK AT FACTORY GATE", 0, 1);
        // $pdf->Ln(10);
        // $pdf->SetX(23);
        // $pdf->Cell(109, 5, "Date & Time Vehicle left Factory:",0, 1);
        // $pdf->Ln(5);
        // $pdf->SetX(23);
        // $pdf->Cell(109, 5, "Name of Security guard                :", 0, 1);
        // $pdf->ln(5);
        // $pdf->SetX(23);
        // $pdf->Cell(189, 5, "Signature                                        :", 0, 0);
       //view mengarah ke invoice.php
        $html = view('invoice');

        // Print text using writeHTMLCell()
        // $pdf->writeHTMLCell(0, 0, '', '', $html, 0, 1, 0, true, '', true);

        // ---------------------------------------------------------
        $this->response->setContentType('application/pdf');
        // Close and output PDF document
        // This method has several options, check the source code documentation for more information.
        $pdf->Output('Gatepass.pdf', 'I');

    }

}