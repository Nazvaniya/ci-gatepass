<footer class="text-center text-lg-start navbar-custom mt-auto" >
  <!-- Copyright -->
  <div class="text-center p-3" style="color:white">
    © <?php echo date('Y'); ?> Copyright:
    <a class="text-light" href="https://panasonic.com/">PANASONIC</a>
  </div>
  <!-- Copyright -->
</footer>