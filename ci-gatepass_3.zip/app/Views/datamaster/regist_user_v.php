<?= $this->extend('templates/index') ?>
<?= $this->section('datamaster/regist_user_v') ?>
<div class="container mt-2">

    <div class="card px-5 py-3 shadow">
        <div  class="row">
            <div class="col-sm-1">
              <img id="access" src="<?= base_url('/image/default.png'); ?>">
            </div>
            <div class="col-sm-11 p-2"> 
              <h5 class="display-5">User Page</h5>
            </div>
        </div>
    </div>

    
    <form>
    <div class="card mt-3 shadow card-body">
    <div class="form-row p-2">
    <div class="form-group col-sm-4">
      <label for="inputno">Employees No</label>
      <input type="text" class="form-control" id="no_employees">
    </div>
    <div class="form-group col-sm-4">
      <label for="inputDepart">Department</label>
      <select id="inputDepart" class="form-control">
        <option selected>Choose...</option>
        <option>...</option>
      </select>
    </div>
    <div class="form-group col-sm-4">
      <label for="inputContact">Contact No</label>
      <input type="text" class="form-control" id="inputContact">
    </div>
  </div>
  <div class="form-row p-2">
    <div class="form-group col-sm-4">
      <label for="inputname">Fullname</label>
      <input type="text" class="form-control" id="name">
    </div>
    <div class="form-group col-sm-4">
      <label for="inputSection">Section</label>
      <select id="inputSection" class="form-control">
        <option selected>Choose...</option>
        <option>...</option>
      </select>
    </div>
    <div class="form-group col-sm-4">
      <label for="inputPassword">Password</label>
      <input type="password" class="form-control" id="password">
    </div>
  </div>
  <div class="form-row p-2">
    <div class="form-group col-sm-4">
      <label for="inputname">Email</label>
      <input type="email" class="form-control" id="email">
    </div>
    <div class="form-group col-sm-4">
      <label for="inputDesignation">Designation</label>
      <select id="inputDesignation" class="form-control">
        <option selected>Choose...</option>
        <option>...</option>
      </select>
    </div>
    <div class="form-group col-sm-4">
      <label for="inputRole">Role</label>
      <select id="inputRole" class="form-control">
        <option selected>Choose...</option>
        <option>...</option>
      </select>
    </div>
    </div>
    <div class="row p-3 justify-content-end">
<div class="col-auto" >  
<button type="button" class="btn btn-primary">Submit</button>
</div>
</div>
</div>
</form>
</div>

</body>
</html>

<script>$(document).ready(function(){
var down = false;

$('#bell').click(function(e){

var color = $(this).text();
if(down){

$('#box').css('height','0px');
$('#box').css('opacity','0');
down = false;
}else{

$('#box').css('height','auto');
$('#box').css('opacity','1');
down = true;

}

});

});</script>
<?= $this->endSection() ?>