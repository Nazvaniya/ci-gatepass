<?= $this->extend('templates/index') ?>

<?= $this->section('datamaster/user_data_v') ?>
<div class="container mt-2">

    <div class="card px-5 py-3 shadow">
        <div  class="row justify-content-end">
            <div class="col-auto mr-auto">
              <img id="access" src="<?= base_url('/image/default.png'); ?>">
            </div>
            <div class="col-sm-11 p-2"> 
              <h5 class="display-5">User Data</h5>
            </div>
            <div class="col-auto">
              <a type="button" href="<?= base_url('home/regist_user')?>" class="btn btn-primary">Add User</a>
        </div>
    </div>
    </div>
    <div class="card mt-3 shadow p-3" style="max-width: 100%">
<div class="table-responsive">
<table id="example" class="table table-striped table-bordered ">
        <thead>
            <tr>
                <th>No</th>
                <th>Employee No</th>
                <th>Full Name</th>
                <th >Email</th>
                <th>Department</th>
                <th>Section</th>
                <th>Designation</th>
                <th>Role</th>
                <th>Contact</th>
                <th>Profile</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td>900433</td>
                <td>Budi Tabuti</td>
                <td>BudiTabuti@panasonic.sg.id</td>
                <td >BMO</td>
                <td >SFPO</td>
                <td >HOD</td>
                <td >Authorized</td>
                <td >48796</td>
                <td>Profile.jpg</td>
                <td>
                    <div class="px-1" >
                        <button class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="bottom" title="Edit" type="button">
                        <i class="bi bi-pencil"></i></button>
                        <button class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="bottom" title="Delete" type="button">
                        <i class="bi bi-trash"></i></button>
                    </div>
                </td>
            </tr>
            <tr>
                <td>2</td>
                <td>900434</td>
                <td>Andi Dian</td>
                <td>AndiDian@panasonic.sg.id</td>
                <td >FGA</td>
                <td >FGA</td>
                <td >HOD</td>
                <td >Authorized</td>
                <td >49756</td>
                <td>Profile.jpg</td>
                <td>
                <div class="px-1" >
                        <button class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="bottom" title="Edit" type="button">
                        <i class="bi bi-pencil"></i></button>
                        <button class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="bottom" title="Delete" type="button">
                        <i class="bi bi-trash"></i></button>
                    </div></td>
            </tr>
          </tbody>
      </table>
</div>

  </div>
  </div>
    </body>
</html>
<script>$(document).ready(function() {
    $('#example').DataTable();
} );</script>
<script>$(document).ready(function(){
var down = false;

$('#bell').click(function(e){

var color = $(this).text();
if(down){

$('#box').css('height','0px');
$('#box').css('opacity','0');
down = false;
}else{

$('#box').css('height','auto');
$('#box').css('opacity','1');
down = true;

}

});

});</script>
<?= $this->endSection() ?>