<?= $this->extend('templates/index') ?>

<?= $this->section('datamaster/regist_userlevel_v') ?>
<div class="container mt-2">

    <div class="card px-5 py-3 shadow">
        <div  class="row">
            <div class="col-sm-1">
              <img id="access" src="<?= base_url('/image/tier.png'); ?>">
            </div>
            <div class="col-sm-11 p-2"> 
              <h5 class="display-5">User Level Page</h5>
            </div>
        </div>
    </div>

    
    <form>
    <div class="card mt-3 shadow card-body">  
    <div class="form-row p-2">
    <div class="form-group col-4">
      <label for="inputuserlevel">User Level</label>
      <input type="text" class="form-control" id="user_level">
    </div>
    </div>
    <div class="row p-3 justify-content-end">
<div class="col-auto" >  
<button type="button" class="btn btn-primary">Submit</button>
</div>
</div>
</div>
</form>


<div class="card mt-3 shadow p-3" style="max-width: 100%">
    <script>$(document).ready(function() {
    $('#example').DataTable();
} );</script>
<div class="table-responsive">
<table id="example" class="table table-striped table-bordered ">
        <thead>
            <tr>
                <th>No</th>
                <th>User Level</th>
                <th>Action</th>
            
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td>Administrator</td>
                <td>
                    <div class="px-1" >
                        <button class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="bottom" title="Edit" type="button">
                        <i class="bi bi-pencil"></i></button>
                        <button class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="bottom" title="Delete" type="button">
                        <i class="bi bi-trash"></i></button>
                    </div>
                </td>
            </tr>
            <tr>
                <td>2</td>
                <td>Authorized</td>
                <td>
                    <div class="px-1">
                        <button class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="bottom" title="Edit" type="button">
                        <i class="bi bi-pencil"></i></button>
                        <button class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="bottom" title="Delete" type="button">
                        <i class="bi bi-trash"></i></button>
                    </div>
                </td>
            </tr>
          </tbody>
      </table>
</div>
  </div>
</div>
</body>
</html>

<script>$(document).ready(function(){
var down = false;

$('#bell').click(function(e){

var color = $(this).text();
if(down){

$('#box').css('height','0px');
$('#box').css('opacity','0');
down = false;
}else{

$('#box').css('height','auto');
$('#box').css('opacity','1');
down = true;

}

});

});</script>
<?= $this->endSection() ?>