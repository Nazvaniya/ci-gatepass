<?= $this->extend('templates/index') ?>
<?= $this->section('datamaster/regist_waste_v') ?>
<div class="container mt-2">

    <div class="card px-5 py-3 shadow">
        <div  class="row">
            <div class="col-sm-1">
              <img id="access" src="<?= base_url('/image/bin.png'); ?>">
            </div>
            <div class="col-sm-11 p-2"> 
              <h5 class="display-5">Waste Page</h5>
            </div>
        </div>
    </div>

    
    <form>
    <div class="card mt-3 shadow card-body">
    <div class="form-row p-2">
    <div class="form-group col">
      <label for="inputItem">Item Name</label>
      <input type="text" class="form-control" id="item_name">
    </div>
    <div class="form-group col">
      <label for="inputTyScrap">Scrap Type</label>
      <select id="inputTyScrap" class="form-control">
        <option selected>Choose...</option>
        <option>Regular</option>
        <option>Irregular</option>
      </select>
    </div>
    </div>
  <div class="form-row p-2">
    <div class="form-group col">
      <label for="inputTyItem">Item Type</label>
      <select id="inputTyItem" class="form-control">
        <option selected>Choose...</option>
        <option>Machine</option>
        <option>Minibus</option>
        <option>Truck</option>
        <option>Exhaust</option>
        <option>Compressor</option>
        <option>container</option>
        <option>Radiator</option>
        <option>Steel</option>
      </select>
    </div>
    <div class="form-group col">
      <label for="inputCategory">Category</label>
      <select id="inputCategory" class="form-control">
        <option selected>Choose...</option>
        <option>Disposal Fixed Asset</option>
        <option>Disposal Raw Material</option>
        <option>Disposal WIP</option>
        <option></option>
        <option></option>
        <option></option>
        <option></option>
      </select>
    </div>
    </div>
    <div class="row p-3 justify-content-end">
<div class="col-auto" >  
<button type="button" class="btn btn-primary">Submit</button>
</div>
</div>
</div>
</form>
</div>
</body>
</html>

<script>$(document).ready(function(){
var down = false;

$('#bell').click(function(e){

var color = $(this).text();
if(down){

$('#box').css('height','0px');
$('#box').css('opacity','0');
down = false;
}else{

$('#box').css('height','auto');
$('#box').css('opacity','1');
down = true;

}

});

});</script>
<?= $this->endSection() ?>