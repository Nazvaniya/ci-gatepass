<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?= base_url("/assets/style.css"); ?>" rel="stylesheet" type="text/css">
    <link href="<?= base_url("/assets/css/bootstrap.min.css"); ?>" rel="stylesheet" type="text/css">
    <link href="<?= base_url("/assets/font-awesome/font-awesome.min.css"); ?>" rel="stylesheet" type="text/css">
    <link href="<?= base_url("/assets/style.css"); ?>" rel="stylesheet" type="text/css">
    <link href="<?= base_url("/assets/css/dataTables.bootstrap4.min.css"); ?>" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.min.js" integrity="sha384-VHvPCCyXqtD5DqJeNxl2dtTyhF78xXNXdkwX1CZeRusQfRKp+tA7hAShOK/B/fQ2" crossorigin="anonymous"></script>
    <script src="<?= base_url("/assets/js/jquery.min.js"); ?>"> </script>
    <script src="<?= base_url("/assets/js/jquery.dataTables.min.js"); ?>"> </script>
    <script src="<?= base_url("/assets/js/dataTables.bootstrap4.min.js"); ?>"> </script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
    p, span, table { font-size: 12px}
  
</style>
    <title>Document</title>
</head>
<body>
<!-- 
<div class="row justify-content-between" > 
    <div class="col-4">   
<span>Retun Type</span>
    </div>
    <div class="col-4">
<span>No.</span>
    </div>
</div>    -->
<!-- <div>
  <table class="table table-borderless">
    <tr>
      <td>Return Type:</td> 
      <td></td>
      <td>No.:</td>
    </tr>
  </table>
</div>

<table class="table table-borderless">
        <tr>
          <td>Gate Pass No</td>
          <td>:</td>
          <td>General/BMO/0002</td>
          <td>Date</td>
          <td>:</td>
          <td><?php echo date('d-m-Y'); ?></td>
        </tr>
         <tr>
          <td>Issued By</td>
          <td>:</td>
          <td>User</td>
          <td>Department</td>
          <td>:</td>
          <td>BMO</td>
        </tr>
        <tr>
        <td>Section</td>
          <td>:</td>
          <td>SFPO</td>
          <td>Goods Status</td>
          <td>:</td>
          <td>NA</td>
        </tr>
      </table>
      <br></br>
      <br></br>
      <table class="table table-borderless">
        <tr>
          <td>Name of Vendor</td>
          <td>:</td>
          <td>PT. Sadar Sana</td>
          <td>Name of Driver</td>
          <td>:</td>
          <td>Budi</td>
          <td>Vehicle Regn No</td>
          <td>:</td>
          <td>Bp 29467 XZ</td>
        </tr>
      </table>
<p></p>
<table id="example" cellpadding="4" class="table table-striped table-bordered p-auto" style="max-width: 100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Type of goods</th>
                <th>Quantity</th>
                <th>Type Unit</th>
                <th>Remark</th>
                <th>Image</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td>Bowl Feeder</td>
                <td>1</td>
                <td>Unit</td>
                <td >Re-work</td>
                <td > <img id="access" src="<?= base_url('/image/bowl.png'); ?>"></td>
            </tr>            
        </tbody>
    </table> -->


</body>
</html>